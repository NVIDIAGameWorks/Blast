$out = [System.IO.Path]::GetTempFileName()
Write-Host $out